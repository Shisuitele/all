#Selection Sort

def ss(l1):
   
    for i in range (len(l1)-1):
        mv = min(l1[i:])
        mi = l1.index(mv,i)
        l1[i],l1[mi] = l1[mi],l1[i]
    return l1

print(ss([1,4,3,2,7,10,12,11]))