def insertion_sort(l1):
    for i in range (1,len(l1)):
        vtc= l1[i]
        
        while l1[i-1] > vtc and i>0:
            l1[i],l1[i-1] = l1[i-1], l1[i] #swap
            i= i-1 
            
    return l1

print(insertion_sort([1,4,5,6,3,3,5,8,9,3]))