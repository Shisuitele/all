def bubble(l1):
    unsorted = True
    
    while unsorted:
        unsorted = False
        
        for i in range(len(l1)-1):
            if l1[i] > l1[i+1]:
                unsorted = True
                l1[i],l1[i+1] = l1[i+1], l1[i] #swap
                
                
    return l1
    
print(bubble([1,7,4,6,3,10]))