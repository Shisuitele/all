if __name__=='__main__':
    arr=[2,4,6,8,9,5]
    x=4
    n=len(arr)

def linear_search(arr,n,x):
    for i in range(0,n):
        if (arr[i==x]):
            return i
    return -1


if linear_search(arr, n, x):
    print("number is present in array at index ")
else:
    print("number is not present in array at index ")